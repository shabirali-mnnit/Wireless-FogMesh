import sys
if int(sys.argv[1]) > 28:
	print("hello")
else:
	print("hi")
		
