import sys
if int(sys.argv[1]) > 50:
	print("humid")
else:
	print("not humid")
		
